
<table id="data-table-default" class="table table-hover table-bordered table-td-valign-middle">
	    <tr><td>Nama Bagian</td><td><?php echo $nama_bagian; ?></td></tr>
	    <tr><td></td><td><button type="button" class="btn btn-info list-data"><i class="fas fa-undo"></i> Kembali</button></td></tr>
	</table>