
<table id="data-table-default" class="table table-hover table-bordered table-td-valign-middle">
    <tr><td>Npk</td><td><?php echo $npk; ?></td></tr>
    <tr><td>Nama Karyawan</td><td><?php echo $nama_karyawan; ?></td></tr>
    <tr><td>Status Karyawan</td><td><?php echo $status_karyawan; ?></td></tr>
    <tr><td>Skill Level</td><td><?php echo $skill_level; ?></td></tr>
    <tr><td></td><td><button type="button" class="btn btn-info list-data"><i class="fas fa-undo"></i> Kembali</button></td></tr>
</table>